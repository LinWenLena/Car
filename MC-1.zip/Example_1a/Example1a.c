#include "LPC17yy.h"


void wait (void){
 int k;					  		  
 for (k=0;k<500000;k++);
}

int main (void){
 int i=0;

FIO1DIR = 0xB0000000;		   // Leds on Port1 defined as Output
FIO2DIR = 0x0000007C;		   // Leds on Port2 defined as Output

while (1){
 FIO1CLR = 0xB0000000;	   //FIO Port 1 - Daten
 FIO1SET = (i&0x00000003)<<28;
 FIO1SET = (i&0x00000004)<<29;
 FIO2CLR = 0x0000007C;	   //FIO Port2 - Daten
 FIO2SET = (i&0x000000F8)>>1;
 i++;
 wait();
}
}
