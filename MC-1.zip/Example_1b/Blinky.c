/*----------------------------------------------------------------------------
 * Name:    Blinky.c
 * Purpose: MCB1700 LED Flasher
 * Note(s):
 *---------------------------------------------------------------------------*/
																			                     
#include "LPC17xx.H"                    /* LPC17xx definitions                */
#include "LEDs.h"


/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void) {
  short i=0;
  long j=0;

  SystemInit();
//  SysTick_Config(SystemFrequency/100);  /* Generate interrupt each 10 ms      */
  LED_init();                           /* LED Initialization                 */

  while (1) {                           /* Loop forever                       */

  if (j++>10000000) 
	{
      j = 0;
	  i &= 0x00FF;
	  LED_Out (i++);  
    }
  }
}
